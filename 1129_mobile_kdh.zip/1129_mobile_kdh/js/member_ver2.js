function validateForm(){
    // 아이디 확인
    let f = document.getElementsByName("signup-form");
    const reg_exp=new RegExp("^(?=.*[a-zA-Z])(?=.*[0-9]).{6,20}$"); 

    const match1 = reg_exp.exec(f.id.value);
    if(match1==null) {
        alert("아이디를 입력해주세요. (영문+숫자 6~20자)")
        return false;
    }

    // 비밀번호 확인
    const reg_exp1=new RegExp("^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{8,20}$");

    const match2 = reg_exp1.exec(f.pass.value);
    if(match2==null){
        alert("8~20자의 영문자, 숫자, 특수기호를 혼합한 비밀번호를 입력해주세요.")
        return false;
    }
    const x1=document.forms["signup-form"]["pass"].value;
    const x2=document.forms["signup-form"]["pass_confirm"].value;
    if(x1 != x2){
    alert("비밀번호가 일치하지 않습니다.")
    return false;
    }

    // 이름 확인
    const x3=document.forms["signup-form"]["name"].value;
    if(x3==null || x==""){
        alert("이름을 입력하세요.");
        return false;
    }
 
    // 전화번호 확인
    const x4=document.forms["signup-form"]["tel"].value;
    if(x4==null || x4==""){
        alert("전화번호를 입력해주세요.")
        return false;
    }

    // 이메일 확인
    const x5=document.forms["signup-form"]["email1"].value;
    if(x5==null || x5==""){
        alert("Email을 입력해주세요.")
        return false;}


    // 생년월일 확인
    const x6=document.forms["signup-form"]["b-year"].value;
    const x7=document.forms["signup-form"]["b-month"].value;
    const x8=document.forms["signup-form"]["b-day"].value;
      if(x6,x7,x8 == null || x6,x7,x8 == ""){
        alert("생년월일을 바르게 입력해주세요.")
        return false;
      }
}
  // 중복 확인 버튼
  document.getElementById("check-id-btn").addEventListener("click", function () {
    const userId = document.getElementById("user-id").value;
    if (userId.length < 6 || userId.length > 20) {
      alert("아이디는 6~20자로 입력해야 합니다.");
      return;
    }
    alert("사용 가능한 아이디입니다."); // 실제로는 서버와 연동 필요
  });
  