$(function(){
    $(".hamburger").click(function(){
        $(".menu").animate({marginLeft:"75%"}),300;
        $("hamburger").css("display","none");
    })

    $(".menu>ul>li>a").on("click",function(){
        
        if($(this).next().is(":visible"))
            {
                $(this).next().stop().slideUp(500);
                $(this).children("img").attr("src","img/source/arrow_down.svg");
            }else{
    
            $(".sub").stop().slideUp(500);
            $(".menu>ul>li>a").children("img").attr("src","img/source/arrow_down.svg");
            $(this).next().stop().slideDown(500);
            $(this).children("img").attr("src","img/source/arrow_up.svg");
            };	
    
    })

    $(".sub>li>a").mouseenter(function(){
        $(this).parent().css("border-bottom","2px solid rgba(144, 0, 32,0.5")
    })

    $(".sub>li>a").mouseleave(function(){
        $(this).parent().css("border","none")
    })

    



$(function(){
    $(".cross").click(function(){
        $(".hamburger").css("display","block");
        $(".menu").animate({marginLeft:"-400px"}),300;
    })
})

})