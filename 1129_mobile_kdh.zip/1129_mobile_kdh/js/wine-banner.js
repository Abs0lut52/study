$(function(){
    const visual = $("#wine-banner>ul>li");
    const button = $("#buttonList>li");
    let current = 0;
    //현재 활성화되어 있는 이미지의 index를 저장하기 위한 변수
 
     let setIntervalId;
 
     button.on({
         click:function(){
             const tg = $(this);
             const i = tg.index();
             button.removeClass("on")
             tg.addClass("on")
 
             move(i)
         }
     })
 
     /* 작업 1 - 배너에 마우스를 얹으면 정지, 마우스를 내리면 다시 인터벌 진행 */
     $("#wine-banner-wrap").on({
         mouseover:function(){
             clearInterval(setIntervalId);
         },
         mouseout:function(){
             timer();
         }
     })
 
 
 
 
 
     /* 작업 2 - 자동으로 n+1 버튼을 눌러서 배너가 자동전환되는 타이머를 설정
              - 배너 하단 버튼을 수동으로 누르면 해당 버튼에 해당되는 배너로 이동 */
         timer();
         function timer(){
             setIntervalId = setInterval(function(){
                 let n = current + 1;
                 if(n == visual.size()){
                     n = 0;
                 }
                 button.eq(n).trigger('click');
             }, 3000)
         }
 
 
 
     function move(i){
         if(current == i) return;
         // 현재 활성화 된 버튼을 다시 누르면 오류가 발생할 수 있기 때문에, 활성화 되어있는 것과 클릭한 것의 index가 같으면 수행중지;
         const currentEl = visual.eq(current);
         // 기존 활성화 index로 활성화 되어있는 이미지를 선택하여 할당
         const nextEl = visual.eq(i); // 활성화 시킬 이미지
 
         currentEl.css({left:0}).stop().animate({left:"-100%"})
         // 이미 활성화 된 이미지(중앙)에서 좌측으로 이동(-100%)
         nextEl.css({left:"100%"}).stop().animate({left:0})
         // 중앙에 활성화 시킬 이미지를 우측(100%)에서 중앙(0)으로 이동
         current = i
     }
 
  });